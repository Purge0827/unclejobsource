const Discord = require("discord.js")
module.exports = {
  name: "help",
  aliases: ["halp"],
  clientPerms: ["EMBED_LINKS"],
  run: async (client, message, args) => {
    const embed = new Discord.MessageEmbed()
    .setTitle("Help Center")
    .setDescription("**Here are list of my commands**")
    .setThumbnail(client.user.displayAvatarURL({ format: "png" }))
      .addField(`Moderation`, '`kick` | `ban` | `slowmode` | `unban` | `nuke` | `lock` | `unlock`')
      .addField(`Information`, '`serverinfo`')
        .addField(`utility`, ' `ping` | `purge` | `avatar` | `snipe` | `steal` | `covid`')
        .addField(`Fun`, '`meme` | `8ball` | `say`')
    .setColor("RANDOM")
    .setTimestamp()
    .setFooter(`Made by Cloudflare#0001`, client.user.displayAvatarURL({ format: "png" }))
    message.channel.send(embed)
  }
}